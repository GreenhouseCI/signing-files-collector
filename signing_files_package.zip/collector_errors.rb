class CollectorError < StandardError

end