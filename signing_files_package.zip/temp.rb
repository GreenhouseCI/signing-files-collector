require 'open3'
require 'plist'
require 'openssl'
require 'base64'

profile_path = "/Users/svetlana/Library/MobileDevice/Provisioning Profiles/f496aaf3-c620-42a6-82e1-9d9544c57b60.mobileprovision"
cmd = ["security", "cms", "-D", "-i", profile_path]

parsed_data = nil

Open3.popen3(*cmd) do |stdin, stdout, stderr, wait_thr|
  exit_status = wait_thr.value
  raise CollectorError(stderr.read) unless exit_status.success?
  parsed_data = Plist::parse_xml(stdout.read.chomp)
end

cert = parsed_data["DeveloperCertificates"][0]

c = OpenSSL::X509::Certificate.new(cert.read)

puts c.serial
# require 'keychain'
# require './codesigning_identity.rb'
#
# keychain = Keychain.default
# puts "not locked" unless keychain.locked?
#
# puts "*" * 57
# puts "Please enter the password to unlock your default keychain"
# puts "*" * 57
# keychain.unlock!
#
# scope = Keychain::Scope.new Sec::Classes::IDENTITY, keychain
# puts "Found #{scope.all.size} codesigning identities in the default keychain"
# if scope.all.empty?
#   raise "No codesigning identities found in the default keychain. Aborting"
# end
# csid = scope.all[0]
# # puts csid.serial
# csid_obj = CodesigningIdentity.new(csid)
# puts csid_obj.serial