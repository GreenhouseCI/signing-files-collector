require "./provisioning_profile.rb"

class ProvisioningProfileCollector
  @@PROVISIONING_PROFILE_DIR = "#{Dir.home}/Library/MobileDevice/Provisioning Profiles"
  @@PROVISIONING_PROFILE_PATTERN = "*.mobileprovision"

  def collect
    profile_path = find_provisioning_profiles
    profiles = profile_path.map {|path| ProvisioningProfile.new(path)}
    profiles = profiles.select{|x| not x.is_expired}
    profiles
  end

  private

  def find_provisioning_profiles
    $file_logger.info "Searching for provisioning profiles in #{@@PROVISIONING_PROFILE_DIR}"
    matches = Array.new
    begin
      puts "#{@@PROVISIONING_PROFILE_DIR}/**/#{@@PROVISIONING_PROFILE_PATTERN}"
      Dir.glob("#{@@PROVISIONING_PROFILE_DIR}/**/#{@@PROVISIONING_PROFILE_PATTERN}").each { |filename|
        matches.push filename
      }
    rescue StandardError => err
      $file_logger.error "Failed to find provisioning profiles: #{err.message}"
      raise CollectorError
    end
    if not matches.any?
      $file_logger.error "No provisioning profiles could be found on this machine. Aborting"
      raise CollectorError
    end
    $file_logger.info "Found #{matches.length} provisioning profiles"
    matches
  end
end